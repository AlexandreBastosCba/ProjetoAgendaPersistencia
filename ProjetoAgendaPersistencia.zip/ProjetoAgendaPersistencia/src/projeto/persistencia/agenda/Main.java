package projeto.persistencia.agenda;


public class Main {
    
    public static void main(String[] args){
        System.out.println("iniciando o projeto");
        
        ContatoGrava contatoGrava = new ContatoGrava();
        Contato contato = new Contato();
        
        contato.setNome("Fernando");
        contato.setTelefone("65-99999-2215");
        
        contatoGrava.persist(contato);
        
         System.out.println("Fim do projeto");
    }
}
